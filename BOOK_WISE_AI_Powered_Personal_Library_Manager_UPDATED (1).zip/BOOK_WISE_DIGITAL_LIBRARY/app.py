import os, sqlite3, secrets
from datetime import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, send_file
from werkzeug.security import generate_password_hash, check_password_hash
from io import BytesIO

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(APP_DIR, "bookwise.db")
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-key")

def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con

def init_db():
    con = db()
    con.executescript("""
    CREATE TABLE IF NOT EXISTS members(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        credits INTEGER DEFAULT 0,
        total_stars INTEGER DEFAULT 0,
        joined_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS books(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        author TEXT NOT NULL,
        genre TEXT DEFAULT 'General',
        description TEXT DEFAULT '',
        rating REAL DEFAULT 0,
        rating_count INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS reading_records(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        member_id INTEGER NOT NULL REFERENCES members(id),
        book_id INTEGER NOT NULL REFERENCES books(id),
        progress INTEGER DEFAULT 0,
        status TEXT DEFAULT 'Reading',
        started_at TEXT DEFAULT CURRENT_TIMESTAMP,
        completed_at TEXT,
        UNIQUE(member_id, book_id)
    );
    CREATE TABLE IF NOT EXISTS reviews(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        member_id INTEGER NOT NULL REFERENCES members(id),
        book_id INTEGER NOT NULL REFERENCES books(id),
        stars INTEGER NOT NULL,
        UNIQUE(member_id, book_id)
    );
    """)
    member_cols = [row[1] for row in con.execute("PRAGMA table_info(members)").fetchall()]
    if "username" not in member_cols:
        con.execute("ALTER TABLE members ADD COLUMN username TEXT")
    con.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_members_username ON members(username)")
    count = con.execute("SELECT COUNT(*) FROM books").fetchone()[0]
    if count == 0:
        sample = [
        ("Atomic Habits","James Clear","Self-help","Small changes, remarkable results."),
        ("The Alchemist","Paulo Coelho","Fiction","A journey towards your personal legend."),
        ("Wings of Fire","A. P. J. Abdul Kalam","Autobiography","The inspiring life story of Dr. Kalam."),
        ("Ikigai","Héctor García and Francesc Miralles","Lifestyle","Discover the Japanese secret to a long and happy life."),
        ("Rich Dad Poor Dad","Robert T. Kiyosaki","Finance","Lessons about money and financial independence."),
        ("The Psychology of Money","Morgan Housel","Finance","Timeless lessons on wealth and behaviour."),
        ("Deep Work","Cal Newport","Productivity","Rules for focused success in a distracted world."),
        ("Harry Potter and the Philosopher's Stone","J. K. Rowling","Fantasy","A young wizard discovers a magical world."),
        ("The 5 AM Club","Robin Sharma","Self-help","Own your morning and elevate your life."),
        ("Ponniyin Selvan","Kalki Krishnamurthy","Historical fiction","A celebrated historical Tamil novel.")
        ]
        con.executemany("INSERT INTO books(title,author,genre,description) VALUES(?,?,?,?)", sample)
    # Original short learning content used by the in-app reader.
    con.execute("CREATE TABLE IF NOT EXISTS book_pages(id INTEGER PRIMARY KEY AUTOINCREMENT, book_id INTEGER NOT NULL REFERENCES books(id), page_no INTEGER NOT NULL, heading TEXT NOT NULL, content TEXT NOT NULL, UNIQUE(book_id,page_no))")
    # Add demo reading activity once; these are clearly labelled demo accounts.
    demo_book = con.execute("SELECT id FROM books WHERE title=?", ("Python Basics: A Beginner's Guide",)).fetchone()
    if not demo_book:
        cur = con.execute("INSERT INTO books(title,author,genre,description,rating,rating_count) VALUES(?,?,?,?,?,?)", ("Python Basics: A Beginner's Guide","BOOK_WISE Learning Team","Programming","An original 10-part introduction to Python programming, available to read inside BookWise.",4.8,12))
        book_id = cur.lastrowid
    else:
        book_id = demo_book[0]
    pages = [
      (1,"Welcome to Python","Python is a beginner-friendly programming language. Programmers use it to build websites, automate tasks, analyse data, and create applications. In this guide, you will learn one small idea at a time."),
      (2,"Your first program","A Python program is a set of instructions. The print() function displays information on the screen. Example: print('Hello, world!'). Text values are called strings and are usually written inside quotation marks."),
      (3,"Variables and values","Variables give names to values. For example, learner = 'Asha' stores text and score = 10 stores a number. Python can work with integers, decimal numbers, strings, and Boolean values such as True and False."),
      (4,"Working with input","The input() function lets a program ask the user for information. Example: name = input('Your name: '). The returned value is text. Use int() when you need to convert a numeric string into a whole number."),
      (5,"Making decisions","An if statement lets a program choose what to do. Example: if score >= 50: print('Pass') else: print('Try again'). Indentation is important in Python because it groups the instructions that belong together."),
      (6,"Repeating with loops","A for loop repeats an action for each item in a sequence. A while loop repeats as long as a condition remains true. Loops help avoid writing the same instruction many times."),
      (7,"Lists","A list stores several values in order. Example: subjects = ['Maths', 'Science', 'Computing']. Index positions start at zero, so subjects[0] is 'Maths'. Use append() to add a new item."),
      (8,"Functions","A function is a reusable block of code. Define one with def, followed by its name and parentheses. Example: def greet(name): return 'Hello ' + name. Call it with greet('Ravi'). Functions make programs easier to organise and test."),
      (9,"Dictionaries and debugging","A dictionary stores information as key-value pairs, such as student = {'name': 'Mina', 'grade': 10}. When code does not work, read the error message, check spelling and indentation, and test one change at a time."),
      (10,"Your next steps","You have completed this introduction. Practise by building a calculator, a quiz, or a simple book tracker. Read documentation, experiment with small examples, and remember that debugging is a normal part of programming. Keep learning!")]
    for page_no, heading, content in pages:
        con.execute("INSERT OR IGNORE INTO book_pages(book_id,page_no,heading,content) VALUES(?,?,?,?)", (book_id,page_no,heading,content))
    demos = [("Demo Reader One","demo50@bookwise.test",50,30,0),("Demo Reader Two","demo90@bookwise.test",90,50,0),("Demo Reader Three","demo100@bookwise.test",100,105,5)]
    for name,email,progress,credits,stars in demos:
        member = con.execute("SELECT id FROM members WHERE email=?",(email,)).fetchone()
        if not member:
            cur = con.execute("INSERT INTO members(name,email,password,credits,total_stars) VALUES(?,?,?,?,?)",(name,email,generate_password_hash("Demo@123"),credits,stars))
            member_id = cur.lastrowid
        else:
            member_id = member[0]
        rec = con.execute("SELECT id FROM reading_records WHERE member_id=? AND book_id=?",(member_id,book_id)).fetchone()
        if not rec:
            completed = datetime.now().isoformat(timespec="seconds") if progress == 100 else None
            con.execute("INSERT INTO reading_records(member_id,book_id,progress,status,completed_at) VALUES(?,?,?,?,?)",(member_id,book_id,progress,"Completed" if progress==100 else "Reading",completed))
    # Requested judge/demo account: fully completed Python book + certificate.
    vindya = con.execute("SELECT id FROM members WHERE email=?", ("vindya@gmail.com",)).fetchone()
    if not vindya:
        cur = con.execute("INSERT INTO members(name,email,password,credits,total_stars,username) VALUES(?,?,?,?,?,?)",
                          ("Vindya", "vindya@gmail.com", generate_password_hash("123456"), 105, 5, "vindya"))
        vindya_id = cur.lastrowid
    else:
        vindya_id = vindya[0]
        con.execute("UPDATE members SET username='vindya', credits=105, total_stars=5 WHERE id=?", (vindya_id,))
    con.execute("INSERT OR IGNORE INTO reading_records(member_id,book_id,progress,status,completed_at) VALUES(?,?,100,'Completed',?)",
                (vindya_id, book_id, datetime.now().isoformat(timespec="seconds")))
    con.execute("UPDATE reading_records SET progress=100,status='Completed',completed_at=COALESCE(completed_at,?) WHERE member_id=? AND book_id=?",
                (datetime.now().isoformat(timespec="seconds"), vindya_id, book_id))
    # Assign stable usernames to the demo accounts too.
    for uname, em in [("demo50", "demo50@bookwise.test"), ("demo90", "demo90@bookwise.test"), ("demo100", "demo100@bookwise.test")]:
        con.execute("UPDATE members SET username=? WHERE email=? AND (username IS NULL OR username='')", (uname, em))
    con.commit()
    con.close()

def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get("member_id"):
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapped

@app.context_processor
def inject_member():
    if session.get("member_id"):
        con=db()
        m=con.execute("SELECT * FROM members WHERE id=?",(session["member_id"],)).fetchone()
        con.close()
        return {"current_member":m}
    return {"current_member":None}

@app.route("/")
def home():
    if session.get("member_id"): return redirect(url_for("dashboard"))
    return render_template("home.html")

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method=="POST":
        name=request.form.get("name","").strip()
        username=request.form.get("username","").strip().lower()
        email=request.form.get("email","").strip().lower()
        password=request.form.get("password","")
        if not name or not username or not email or len(password)<6:
            flash("Enter all details. Password must contain at least 6 characters.","error")
        else:
            con=db()
            try:
                con.execute("INSERT INTO members(name,email,password,credits,username) VALUES(?,?,?,5,?)",
                            (name,email,generate_password_hash(password),username))
                con.commit()
                flash("Account created! You received 5 welcome credits. Please log in.","success")
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                flash("Username or email is already registered.","error")
            finally: con.close()
    return render_template("register.html")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method=="POST":
        con=db()
        identity=request.form.get("identity", "").strip().lower()
        m=con.execute("SELECT * FROM members WHERE lower(email)=? OR lower(username)=?",(identity,identity)).fetchone()
        con.close()
        if m and check_password_hash(m["password"],request.form.get("password","")):
            session["member_id"]=m["id"]
            session["member_name"]=m["name"]
            return redirect(url_for("dashboard"))
        flash("Invalid email or password.","error")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))

@app.route("/dashboard")
@login_required
def dashboard():
    con=db()
    mid=session["member_id"]
    member=con.execute("SELECT * FROM members WHERE id=?",(mid,)).fetchone()
    records=con.execute("""SELECT r.*,b.title,b.author,b.rating FROM reading_records r
                           JOIN books b ON b.id=r.book_id WHERE r.member_id=? ORDER BY r.started_at DESC""",(mid,)).fetchall()
    active=con.execute("""SELECT COUNT(*) FROM reading_records WHERE member_id=? AND status='Reading'""",(mid,)).fetchone()[0]
    completed=con.execute("""SELECT COUNT(*) FROM reading_records WHERE member_id=? AND status='Completed'""",(mid,)).fetchone()[0]
    con.close()
    return render_template("dashboard.html",member=member,records=records,active=active,completed=completed)

@app.route("/books")
@login_required
def books():
    q=request.args.get("q","").strip()
    con=db()
    if q:
        rows=con.execute("SELECT * FROM books WHERE title LIKE ? OR author LIKE ? ORDER BY title",
                         (f"%{q}%",f"%{q}%")).fetchall()
    else:
        rows=con.execute("SELECT * FROM books ORDER BY title").fetchall()
    con.close()
    return render_template("books.html",books=rows,q=q)

@app.route("/book/<int:book_id>")
@login_required
def book_detail(book_id):
    con=db()
    book=con.execute("SELECT * FROM books WHERE id=?",(book_id,)).fetchone()
    record=con.execute("SELECT * FROM reading_records WHERE member_id=? AND book_id=?",
                       (session["member_id"],book_id)).fetchone()
    con.close()
    if not book: return "Book not found",404
    return render_template("book_detail.html",book=book,record=record)

@app.route("/start/<int:book_id>",methods=["POST"])
@login_required
def start_reading(book_id):
    con=db()
    exists=con.execute("SELECT id FROM books WHERE id=?",(book_id,)).fetchone()
    if exists:
        try:
            con.execute("INSERT INTO reading_records(member_id,book_id) VALUES(?,?)",(session["member_id"],book_id))
            con.commit()
            flash("Book added to your reading list! Keep going.","success")
        except sqlite3.IntegrityError:
            flash("This book is already in your reading list.","info")
    con.close()
    return redirect(url_for("book_detail",book_id=book_id))

@app.route("/progress/<int:record_id>",methods=["POST"])
@login_required
def update_progress(record_id):
    try: progress=max(0,min(100,int(request.form.get("progress",0))))
    except ValueError: progress=0
    con=db()
    rec=con.execute("SELECT * FROM reading_records WHERE id=? AND member_id=?",
                    (record_id,session["member_id"])).fetchone()
    if rec:
        old=rec["progress"]
        # Progress and rewards never move backwards. Earn 1 credit per 2% progress,
        # plus a one-time 50-credit and 5-star completion bonus.
        progress=max(old,progress)
        status="Completed" if progress==100 else "Reading"
        completed_at=rec["completed_at"] or (datetime.now().isoformat(timespec="seconds") if progress==100 else None)
        con.execute("UPDATE reading_records SET progress=?,status=?,completed_at=? WHERE id=?",
                    (progress,status,completed_at,record_id))
        earned_before=old//2
        earned_now=progress//2
        bonus=50 if progress==100 and old<100 else 0
        stars=5 if progress==100 and old<100 else 0
        con.execute("UPDATE members SET credits=credits+? ,total_stars=total_stars+? WHERE id=?",
                    (earned_now-earned_before+bonus,stars,session["member_id"]))
        if bonus:
            flash("Congratulations! You completed the book and earned +50 bonus credits and 5 stars. Your certificate is ready!","success")
        else: flash("Reading progress saved. You earned credits for your progress!","success")
        con.commit()
    con.close()
    return redirect(url_for("dashboard"))

@app.route("/read/<int:book_id>")
@login_required
def read_book(book_id):
    con=db()
    book=con.execute("SELECT * FROM books WHERE id=?",(book_id,)).fetchone()
    record=con.execute("SELECT * FROM reading_records WHERE member_id=? AND book_id=?",(session["member_id"],book_id)).fetchone()
    pages=con.execute("SELECT * FROM book_pages WHERE book_id=? ORDER BY page_no",(book_id,)).fetchall()
    con.close()
    if not book: return "Book not found",404
    if not record: return redirect(url_for("book_detail",book_id=book_id))
    return render_template("reader.html",book=book,record=record,pages=pages)

@app.route("/read/<int:book_id>/progress",methods=["POST"])
@login_required
def mark_read_page(book_id):
    try: page_no=max(1,int(request.form.get("page_no",1)))
    except ValueError: page_no=1
    con=db()
    total=con.execute("SELECT COUNT(*) FROM book_pages WHERE book_id=?",(book_id,)).fetchone()[0]
    rec=con.execute("SELECT * FROM reading_records WHERE member_id=? AND book_id=?",(session["member_id"],book_id)).fetchone()
    con.close()
    if not rec or total==0: return redirect(url_for("book_detail",book_id=book_id))
    progress=min(100,round(min(page_no,total)*100/total))
    old=rec["progress"]
    progress=max(old,progress)
    status="Completed" if progress==100 else "Reading"
    completed_at=rec["completed_at"] or (datetime.now().isoformat(timespec="seconds") if progress==100 else None)
    con=db()
    con.execute("UPDATE reading_records SET progress=?,status=?,completed_at=? WHERE id=?",(progress,status,completed_at,rec["id"]))
    bonus=50 if progress==100 and old<100 else 0
    stars=5 if progress==100 and old<100 else 0
    con.execute("UPDATE members SET credits=credits+? ,total_stars=total_stars+? WHERE id=?",(progress//2-old//2+bonus,stars,session["member_id"]))
    con.commit(); con.close()
    if bonus: flash("Book completed! +50 bonus credits and 5 stars. Certificate unlocked!","success")
    else: flash("Page marked as read. Your reading progress and credits are updated.","success")
    return redirect(url_for("read_book",book_id=book_id))

@app.route("/rate/<int:book_id>",methods=["POST"])
@login_required
def rate_book(book_id):
    try: stars=max(1,min(5,int(request.form.get("stars",5))))
    except ValueError: stars=5
    con=db()
    con.execute("INSERT INTO reviews(member_id,book_id,stars) VALUES(?,?,?) ON CONFLICT(member_id,book_id) DO UPDATE SET stars=excluded.stars",
                (session["member_id"],book_id,stars))
    avg=con.execute("SELECT AVG(stars),COUNT(*) FROM reviews WHERE book_id=?",(book_id,)).fetchone()
    con.execute("UPDATE books SET rating=?,rating_count=? WHERE id=?",(round(avg[0],1),avg[1],book_id))
    con.commit(); con.close()
    flash("Thanks for rating this book!","success")
    return redirect(url_for("book_detail",book_id=book_id))

@app.route("/community")
@login_required
def community():
    con=db()
    rows=con.execute("""SELECT m.name,b.title,b.author,r.progress,r.status,r.started_at
                        FROM reading_records r JOIN members m ON m.id=r.member_id
                        JOIN books b ON b.id=r.book_id ORDER BY r.started_at DESC""").fetchall()
    con.close()
    return render_template("community.html",records=rows)

@app.route("/certificate/<int:record_id>")
@login_required
def certificate(record_id):
    con=db()
    rec=con.execute("""SELECT m.name,b.title,b.author,r.completed_at FROM reading_records r
                       JOIN members m ON m.id=r.member_id JOIN books b ON b.id=r.book_id
                       WHERE r.id=? AND r.member_id=? AND r.status='Completed'""",
                    (record_id,session["member_id"])).fetchone()
    con.close()
    if not rec: return "Certificate is available after completing the book.",403
    return render_template("certificate.html",record=rec)

@app.route("/chatbot",methods=["POST"])
@login_required
def chatbot():
    message=request.json.get("message","").strip()
    if not message: return jsonify(reply="Ask me something about reading or books!")
    # Optional live AI: set OPENAI_API_KEY and install openai package.
    api_key=os.environ.get("OPENAI_API_KEY")
    if api_key:
        try:
            from openai import OpenAI
            client=OpenAI(api_key=api_key)
            response=client.responses.create(model=os.environ.get("OPENAI_MODEL","gpt-4.1-mini"),
                instructions="You are BookWise, a friendly reading assistant. Help with book suggestions, summaries, reading plans and motivation. Do not claim to know a book's full text.",
                input=message)
            return jsonify(reply=response.output_text)
        except Exception:
            pass
    lower=message.lower()
    if "recommend" in lower or "suggest" in lower:
        reply="Try Atomic Habits for practical habits, The Alchemist for an inspiring story, or Wings of Fire for motivation. You can search by title or author in the Books page."
    elif "motivat" in lower or "lazy" in lower or "bored" in lower:
        reply="You can do it! Read just 10 pages today. Small daily progress becomes a finished book. Update your reading percentage to earn completion stars."
    elif "plan" in lower or "schedule" in lower:
        reply="Try a simple plan: 15 minutes every day, one small target per session, and update your progress after reading. Aim for consistency, not speed."
    elif "rating" in lower or "star" in lower:
        reply="Open a book's details page to give it a 1–5 star rating. Completing a book earns 5 stars and 50 credits."
    else:
        reply="I'm BookWise, your reading buddy! Ask me for book recommendations, a reading plan, motivation, or help using the library. For a live AI conversation, add OPENAI_API_KEY as described in README."
    return jsonify(reply=reply)

if __name__=="__main__":
    init_db()
    app.run(debug=True)

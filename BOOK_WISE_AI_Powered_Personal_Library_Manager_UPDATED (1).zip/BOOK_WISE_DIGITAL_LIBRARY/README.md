# BOOK_WISE DIGITAL LIBRARY

A Flask + SQLite reading-tracker project with member accounts, book search, reading progress, ratings, credits, stars, community activity, completion certificates, and a BookWise chatbot.

## Features
- Member registration and login (passwords are hashed).
- New members receive 100 welcome credits.
- Book catalogue with search by **book title OR author name**.
- Add books to a personal reading shelf.
- Update reading progress from 0–100%.
- Dashboard shows credits, stars, currently-reading count, completed books, and reading history.
- Community page shows **who is reading which book** and their progress.
- Rate books from 1–5 stars; average rating updates on the book page.
- Completing a book (100%) awards 50 credits and 5 stars, once per book.
- Completion certificate with print option.
- Floating BookWise reading assistant chatbot.
- Includes 10 starter books; add more in the database as needed.

## Setup (Windows / VS Code)
1. Install Python 3.10 or newer.
2. Extract the ZIP and open the `BOOK_WISE_DIGITAL_LIBRARY` folder in VS Code.
3. Open Terminal in that folder.
4. Create a virtual environment:
   ```bash
   py -m venv venv
   ```
5. Activate it:
   ```bash
   venv\Scripts\activate
   ```
6. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
7. Start the app:
   ```bash
   python app.py
   ```
8. Open `http://127.0.0.1:5000` in your browser.
9. Register a new member and start exploring.

## Chatbot: local mode and live AI mode
The chatbot works immediately in local assistant mode (book suggestions, reading motivation, simple reading plans, and help using BookWise).

To enable live AI responses:
1. Create an API key with your chosen AI provider.
2. Set it as an environment variable (do not paste the key into source code or share it):
   ```powershell
   $env:OPENAI_API_KEY="your-api-key"
   ```
3. Optional model override:
   ```powershell
   $env:OPENAI_MODEL="gpt-4.1-mini"
   ```
4. Install the optional package:
   ```bash
   pip install openai
   ```
5. Restart `python app.py`.

Live AI use may incur API charges. Without an API key, the built-in local chatbot remains available.

## Notes
- SQLite database `bookwise.db` is created automatically on first run.
- Change `SECRET_KEY` before deploying publicly.
- This is a learning/demo project. For a public deployment, add CSRF protection, rate limiting, stronger privacy controls, and production server configuration.


## Demo reading-progress accounts
The first launch seeds three clearly labelled demo accounts to demonstrate reading progress and certificates. They all use the password `Demo@123`:

- `demo50@bookwise.test` — 50% progress, 30 credits
- `demo90@bookwise.test` — 90% progress, 50 credits
- `demo100@bookwise.test` — 100% complete, 105 credits, 5 stars, certificate unlocked

Open **Python Basics: A Beginner's Guide** from the reader shelf. Its 10 short learning sections are original sample content. Mark each section as read to update progress. New members start with 5 credits; they earn 1 credit per 2% reading progress, plus a one-time 50-credit and 5-star bonus at 100%. Demo accounts are for demonstration only.

## Demo reading accounts
The app seeds three clearly labelled demo readers for demonstrating reading progress, credits, stars, and certificates. All three use the same original in-app sample book, **Python Basics: A Beginner's Guide**.

| Demo user | Email | Password | Starting demo progress | Credits | Stars |
|---|---|---|---:|---:|---:|
| Demo Reader One | demo50@bookwise.test | Demo@123 | 50% | 30 | 0 |
| Demo Reader Two | demo90@bookwise.test | Demo@123 | 90% | 50 | 0 |
| Demo Reader Three | demo100@bookwise.test | Demo@123 | 100% | 105 | 5 |

New accounts start with 5 credits. Reading earns 1 credit per 2 percentage points of progress. Completing a book adds a one-time 50-credit bonus and 5 stars, and unlocks the completion certificate. Demo account data is sample data; real members' balances are not reset when the app starts.
